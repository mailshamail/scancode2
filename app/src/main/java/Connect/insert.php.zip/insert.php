<?php

$database = 'f0587338_scancode';
$user = 'f0587338_scancode';
$password = 'fE3yBVin';
$db_server = 'localhost';

$db = new PDO("mysql:host={$db_server};dbname={$database};charset=utf8", $user, $password);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "connect";
header('Content-Type: application/json');

 if (isset($_GET["action"])) {
    $action = $_GET['action'];
}

if($action == insert){
    $json=$_POST['json'];

$form=$array->form;
$query=$array->query;
$fields=$array->fields;

$stmt = $db->prepare("INSERT INTO form(form,query,fields) VALUES (?,?,?)");


//$db->prepare("INSERT INTO 'form'(
 //   `form` ,
 //   `query` ,
//)
//VALUES(
//    'form' ,
//    'query' ,
 //   JSON_OBJECT(
 //       'fields',
 //       JSON_ARRAY('fields'))";

$stmt->execute([$form,$query,$fields]);

echo json_decode($json);
print_r($json);

}
?>