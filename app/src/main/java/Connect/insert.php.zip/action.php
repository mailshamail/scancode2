//<?php

//$response = array();

//$database = 'f0587338_scancode';
//$user = 'f0587338_scancode';
//$password = 'fE3yBVin';

//$con = mysqli_connect('localhost', $user, $password);
//echo "connect";
//mysqli_select_db($database, $con);

//$query = "SELECT * FROM form";
//$result = mysqli_query($query);

//$insert = mysql_query("INSERT INTO form(id, ser, field) VALUES('$name', '$price', '$description')");


// if (isset($_GET["action"])) {
  //  $action = $_GET['action'];
//}

//if($action == select){
//if ($result) {
      //  $response["success"] = 1;
    //    $response["message"] = "Product successfully created.";

  //      echo json_encode($response);
    
//}
//}
//?>


<?php

$db_server = 'localhost';
$database = 'f0587338_scancode';
$user = 'f0587338_scancode';
$password = 'fE3yBVin';

$db = new PDO("mysql:host={$db_server};dbname={$database};charset=utf8", $user, $password);
echo "coonect";
header('Content-Type: application/json');

$stmt = $db->prepare("SELECT * FROM form");
$stmt->execute([$id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

 if (isset($_GET["action"])) {
    $action = $_GET['action'];
}

if($action == select){
if ($result) 
{
   echo json_encode($response);
}
}

?>

